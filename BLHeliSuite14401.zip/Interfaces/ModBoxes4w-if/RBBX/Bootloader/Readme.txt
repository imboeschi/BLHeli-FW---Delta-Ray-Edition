Thanks a lot to Hagen Re for sharing his AVRootloader (AVR Bootloader) project. 
This bootloader is small enough (<512 bytes) and though provides Eeprom writing access. 
For further info see: http://www.mikrocontroller.net/topic/avr-bootloader-mit-verschluesselung.
Source Ver. 6.0 is available here: http://www.mikrocontroller.net/topic/avr-bootloader-mit-verschluesselung#1195903